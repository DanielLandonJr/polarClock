A Pen created at CodePen.io. You can find this one at https://codepen.io/DanielLandonJr/pen/NzrOEZ.

 Inspired by <a href="http://blog.pixelbreaker.com/polarclock"> Flash Polar Clock</a> by pixelbreaker